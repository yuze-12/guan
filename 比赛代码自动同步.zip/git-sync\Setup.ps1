﻿#Requires -Version 5.1
<#
.SYNOPSIS
    比赛代码自动同步 —— 安装向导（图形界面 / 静默安装）

.DESCRIPTION
    弹出一个小窗口让你选工作区、填 Git 仓库地址，然后自动完成：
    git init / 配置 remote / 写 .gitignore / 注册开机自启 / 首次同步 / 启动后台同步。
    重复运行可以改配置。

    也可以用命令行静默安装（适合批量部署）：
        powershell -ExecutionPolicy Bypass -File Setup.ps1 `
            -Workspace "D:\code" -RepoUrl "https://gitee.com/u/repo.git" `
            -UserName "张三" -UserEmail "zhangsan@example.com"

.PARAMETER Workspace
    静默安装：工作区目录

.PARAMETER RepoUrl
    静默安装：Git 仓库地址

.PARAMETER Branch
    分支，默认 main

.PARAMETER UserName
    提交者名字

.PARAMETER UserEmail
    提交者邮箱

.PARAMETER NoAutoStart
    静默安装：不设置开机自启
#>
[CmdletBinding()]
param(
    [string]$Workspace = '',
    [string]$RepoUrl = '',
    [string]$Branch = 'main',
    [string]$UserName = '',
    [string]$UserEmail = '',
    [switch]$NoAutoStart
)

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false } catch { }

function Get-PathId {
    param([string]$Path)
    $sha = [System.Security.Cryptography.SHA1]::Create()
    try { $hash = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Path.ToLowerInvariant())) }
    finally { $sha.Dispose() }
    return (($hash | ForEach-Object { $_.ToString('x2') }) -join '').Substring(0, 8)
}

$ToolDir    = $PSScriptRoot
$ConfigPath = Join-Path $ToolDir 'config.json'
$SyncScript = Join-Path $ToolDir 'GitSync.ps1'
$HiddenVbs  = Join-Path $ToolDir 'git-sync-hidden.vbs'
$RunKey     = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$RunValue   = 'CompetitionGitAutoSync_' + (Get-PathId $ToolDir)
$Utf8NoBom  = New-Object System.Text.UTF8Encoding $false

$Silent = $false
$Vals   = $null

# ---------------------------------------------------------------- 工具函数

function Invoke-Git {
    param([Parameter(Mandatory)][string[]]$Arguments)

    $previous = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $lines = & git @Arguments 2>&1
        $code  = $LASTEXITCODE
        if ($null -eq $lines) { $text = '' } else { $text = (($lines | ForEach-Object { "$_" }) -join "`n") }
    } finally {
        $ErrorActionPreference = $previous
    }
    [pscustomobject]@{ Code = $code; Text = $text.Trim() }
}

function Show-Info {
    param([string]$Message, [string]$Title = '提示', [string]$Icon = 'Information')
    if ($Silent) {
        Write-Host ''
        Write-Host $Message
        Write-Host ''
    } else {
        [System.Windows.Forms.MessageBox]::Show($Message, $Title, 'OK', $Icon) | Out-Null
    }
}

# ---------------------------------------------------------------- 环境检查

$gitCmd = Get-Command git -ErrorAction SilentlyContinue
if (-not $gitCmd) {
    $m = "没有检测到 Git，请先安装：`n`nhttps://git-scm.com/download/win`n`n安装时一路点『下一步』即可。装完再双击本文件。"
    Write-Host $m -ForegroundColor Red
    exit 1
}

# ---------------------------------------------------------------- 静默模式

if (-not [string]::IsNullOrWhiteSpace($Workspace) -and -not [string]::IsNullOrWhiteSpace($RepoUrl)) {
    $Silent = $true
    if ([string]::IsNullOrWhiteSpace($UserName))  { $UserName  = $env:USERNAME }
    if ([string]::IsNullOrWhiteSpace($UserEmail)) { $UserEmail = ($env:USERNAME + '@' + $env:COMPUTERNAME) }
    if ([string]::IsNullOrWhiteSpace($Branch))    { $Branch    = 'main' }

    $Vals = @{
        workspace = $Workspace
        remoteUrl = $RepoUrl
        branch    = $Branch
        userName  = $UserName
        userEmail = $UserEmail
        autoStart = (-not $NoAutoStart)
    }
}

# ---------------------------------------------------------------- 图形界面

if (-not $Silent) {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $old = $null
    if (Test-Path -LiteralPath $ConfigPath) {
        try {
            $old = [System.IO.File]::ReadAllText($ConfigPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
        } catch { $old = $null }
    }

    $defaultWs     = ''
    $defaultUrl    = ''
    $defaultBranch = 'main'
    $defaultName   = ''
    $defaultEmail  = ''

    if ($old) {
        if ($old.workspace)  { $defaultWs  = [string]$old.workspace }
        if ($old.remoteUrl)  { $defaultUrl = [string]$old.remoteUrl }
        if ($old.branch)     { $defaultBranch = [string]$old.branch }
        if ($old.userName)   { $defaultName  = [string]$old.userName }
        if ($old.userEmail)  { $defaultEmail = [string]$old.userEmail }
    }
    # 故意不给默认值：预填「工具自己所在的文件夹」最容易让人一路回车选错，
    # 结果同步了个空仓库还以为装好了。这里强制用户自己点『浏览…』选一次。

    if (-not $defaultName) {
        $n = Invoke-Git @('config', '--global', 'user.name')
        if ($n.Code -eq 0) { $defaultName = $n.Text }
    }
    if (-not $defaultEmail) {
        $e = Invoke-Git @('config', '--global', 'user.email')
        if ($e.Code -eq 0) { $defaultEmail = $e.Text }
    }
    if (-not $defaultName)  { $defaultName = $env:USERNAME }
    if (-not $defaultEmail) { $defaultEmail = ($env:USERNAME + '@' + $env:COMPUTERNAME) }

    $font      = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
    $fontTitle = New-Object System.Drawing.Font('Microsoft YaHei UI', 13, [System.Drawing.FontStyle]::Bold)
    $fontSmall = New-Object System.Drawing.Font('Microsoft YaHei UI', 8)

    $form = New-Object System.Windows.Forms.Form
    $form.Text = '比赛代码自动同步 · 设置'
    $form.Size = New-Object System.Drawing.Size(640, 520)
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.TopMost = $true
    $form.Font = $font

    $title = New-Object System.Windows.Forms.Label
    $title.Text = '把比赛代码自动同步到 Git 仓库'
    $title.Font = $fontTitle
    $title.AutoSize = $true
    $title.Location = New-Object System.Drawing.Point(24, 18)
    $form.Controls.Add($title)

    $sub = New-Object System.Windows.Forms.Label
    $sub.Text = '选一个文件夹当工作区，之后里面任何改动都会自动提交并推送到 Git 仓库，开机自动运行。'
    $sub.Font = $fontSmall
    $sub.ForeColor = [System.Drawing.Color]::DimGray
    $sub.AutoSize = $true
    $sub.Location = New-Object System.Drawing.Point(26, 52)
    $form.Controls.Add($sub)

    function New-Label {
        param($Text, $X, $Y)
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $Text
        $l.AutoSize = $true
        $l.Location = New-Object System.Drawing.Point($X, $Y)
        $form.Controls.Add($l)
        $l
    }

    $y = 90
    New-Label '工作区目录（放你代码的那个文件夹，点『浏览…』选；不要选成这个工具自己的文件夹）' 24 $y | Out-Null
    $y += 24
    $tbWs = New-Object System.Windows.Forms.TextBox
    $tbWs.Location = New-Object System.Drawing.Point(26, $y)
    $tbWs.Size = New-Object System.Drawing.Size(460, 24)
    $tbWs.Text = $defaultWs
    $form.Controls.Add($tbWs)

    $btnBrowse = New-Object System.Windows.Forms.Button
    $btnBrowse.Text = '浏览…'
    $btnBrowse.Location = New-Object System.Drawing.Point(494, ($y - 2))
    $btnBrowse.Size = New-Object System.Drawing.Size(90, 26)
    $form.Controls.Add($btnBrowse)

    $y += 40
    New-Label 'Git 仓库地址（在 GitHub / Gitee 上新建一个空仓库，复制地址粘这里）' 24 $y | Out-Null
    $y += 24
    $tbUrl = New-Object System.Windows.Forms.TextBox
    $tbUrl.Location = New-Object System.Drawing.Point(26, $y)
    $tbUrl.Size = New-Object System.Drawing.Size(558, 24)
    $tbUrl.Text = $defaultUrl
    $form.Controls.Add($tbUrl)

    $y += 26
    $hint = New-Object System.Windows.Forms.Label
    $hint.Text = '例：https://gitee.com/你的用户名/competition.git   或   git@github.com:用户名/competition.git'
    $hint.Font = $fontSmall
    $hint.ForeColor = [System.Drawing.Color]::DimGray
    $hint.AutoSize = $true
    $hint.Location = New-Object System.Drawing.Point(26, $y)
    $form.Controls.Add($hint)

    $y += 34
    New-Label '分支' 24 $y | Out-Null
    $tbBranch = New-Object System.Windows.Forms.TextBox
    $tbBranch.Location = New-Object System.Drawing.Point(70, ($y - 3))
    $tbBranch.Size = New-Object System.Drawing.Size(120, 24)
    $tbBranch.Text = $defaultBranch
    $form.Controls.Add($tbBranch)
    New-Label '（新建仓库一般就是 main，不用改）' 200 ($y + 2) | Out-Null

    $y += 40
    New-Label '提交者名字' 24 $y | Out-Null
    $tbName = New-Object System.Windows.Forms.TextBox
    $tbName.Location = New-Object System.Drawing.Point(110, ($y - 3))
    $tbName.Size = New-Object System.Drawing.Size(160, 24)
    $tbName.Text = $defaultName
    $form.Controls.Add($tbName)

    New-Label '邮箱' 300 $y | Out-Null
    $tbMail = New-Object System.Windows.Forms.TextBox
    $tbMail.Location = New-Object System.Drawing.Point(344, ($y - 3))
    $tbMail.Size = New-Object System.Drawing.Size(240, 24)
    $tbMail.Text = $defaultEmail
    $form.Controls.Add($tbMail)

    $y += 40
    $chkAuto = New-Object System.Windows.Forms.CheckBox
    $chkAuto.Text = '开机自动启动（登录 Windows 后自动在后台同步）'
    $chkAuto.AutoSize = $true
    $chkAuto.Checked = $true
    $chkAuto.Location = New-Object System.Drawing.Point(26, $y)
    $form.Controls.Add($chkAuto)

    $y += 56
    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = '开始同步'
    $btnOk.Size = New-Object System.Drawing.Size(150, 36)
    $btnOk.Location = New-Object System.Drawing.Point(288, $y)
    $btnOk.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 10, [System.Drawing.FontStyle]::Bold)
    $form.Controls.Add($btnOk)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = '取消'
    $btnCancel.Size = New-Object System.Drawing.Size(90, 36)
    $btnCancel.Location = New-Object System.Drawing.Point(456, $y)
    $form.Controls.Add($btnCancel)

    $statusLabel = New-Object System.Windows.Forms.Label
    $statusLabel.Text = ''
    $statusLabel.Font = $fontSmall
    $statusLabel.ForeColor = [System.Drawing.Color]::Firebrick
    $statusLabel.AutoSize = $true
    $statusLabel.Location = New-Object System.Drawing.Point(26, ($y + 8))
    $form.Controls.Add($statusLabel)

    $form.AcceptButton = $btnOk
    $form.CancelButton = $btnCancel

    $script:Accepted = $false

    $btnBrowse.Add_Click({
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = '选择要自动同步到 Git 的工作区文件夹'
        $dialog.ShowNewFolderButton = $true
        if (Test-Path -LiteralPath $tbWs.Text) { $dialog.SelectedPath = $tbWs.Text }
        if ($dialog.ShowDialog() -eq 'OK') { $tbWs.Text = $dialog.SelectedPath }
    })

    $btnCancel.Add_Click({ $form.Close() })

    $btnOk.Add_Click({
        $ws   = $tbWs.Text.Trim()
        $url  = $tbUrl.Text.Trim()
        $br   = $tbBranch.Text.Trim()
        $name = $tbName.Text.Trim()
        $mail = $tbMail.Text.Trim()

        if (-not $ws) { $statusLabel.Text = '请先选工作区目录'; return }
        if (-not (Test-Path -LiteralPath $ws)) {
            $r = [System.Windows.Forms.MessageBox]::Show(
                "目录不存在：`n$ws`n`n要现在创建吗？", '创建目录', 'YesNo', 'Question')
            if ($r -ne 'Yes') { return }
            try { New-Item -ItemType Directory -Path $ws -Force | Out-Null }
            catch { $statusLabel.Text = '创建目录失败'; return }
        }
        if (-not $url)  { $statusLabel.Text = '请填 Git 仓库地址'; return }
        if (-not $br)   { $br = 'main' }
        if (-not $name) { $statusLabel.Text = '请填提交者名字'; return }
        if (-not $mail) { $statusLabel.Text = '请填邮箱'; return }

        $script:Vals = @{
            workspace = (Resolve-Path -LiteralPath $ws).Path
            remoteUrl = $url
            branch    = $br
            userName  = $name
            userEmail = $mail
            autoStart = [bool]$chkAuto.Checked
        }
        $script:Accepted = $true
        $form.Close()
    })

    [void]$form.ShowDialog()

    if (-not $script:Accepted) { exit 0 }
}

if (-not $Vals) { exit 0 }

# ---------------------------------------------------------------- 安装步骤

$values = $Vals

Write-Host ''
Write-Host '===== 比赛代码自动同步 · 开始安装 =====' -ForegroundColor Cyan
Write-Host ''

function Write-Step {
    param([string]$Text)
    Write-Host ('  ' + $Text) -ForegroundColor Cyan
}

function Install-Sync {
    param($V)

    $ws = [System.IO.Path]::GetFullPath($V.workspace)
    $br = $V.branch

    # 1. 仓库
    Write-Step ('准备 Git 仓库：' + $ws)

    if (-not (Test-Path -LiteralPath $ws)) {
        New-Item -ItemType Directory -Path $ws -Force | Out-Null
    }

    if (-not (Test-Path -LiteralPath (Join-Path $ws '.git'))) {
        $r = Invoke-Git @('-C', $ws, 'init', '-q')
        if ($r.Code -ne 0) { throw "git init 失败：$($r.Text)" }
        Write-Host '    已创建新的 Git 仓库' -ForegroundColor Gray
    } else {
        Write-Host '    目录里已有 Git 仓库，沿用它' -ForegroundColor Gray
    }

    $headOk = (Invoke-Git @('-C', $ws, 'rev-parse', '--verify', '--quiet', 'HEAD')).Code -eq 0
    if (-not $headOk) {
        Invoke-Git @('-C', $ws, 'symbolic-ref', 'HEAD', ('refs/heads/' + $br)) | Out-Null
    } else {
        $cr = Invoke-Git @('-C', $ws, 'rev-parse', '--abbrev-ref', 'HEAD')
        if ($cr.Code -eq 0 -and $cr.Text -and $cr.Text -ne 'HEAD' -and $cr.Text -ne $br) {
            Write-Host ('    当前分支是 ' + $cr.Text + '，以它为准') -ForegroundColor Yellow
            $br = $cr.Text
        }
    }

    # 2. remote
    $origin = Invoke-Git @('-C', $ws, 'remote', 'get-url', 'origin')
    if ($origin.Code -eq 0) {
        if ($origin.Text -ne $V.remoteUrl) {
            Invoke-Git @('-C', $ws, 'remote', 'set-url', 'origin', $V.remoteUrl) | Out-Null
            Write-Host '    已更新远程仓库地址' -ForegroundColor Gray
        }
    } else {
        $r = Invoke-Git @('-C', $ws, 'remote', 'add', 'origin', $V.remoteUrl)
        if ($r.Code -ne 0) { throw "添加远程仓库失败：$($r.Text)" }
        Write-Host '    已关联远程仓库' -ForegroundColor Gray
    }

    # 3. 和远程对齐分支（空仓库跟随远程默认分支；已有仓库沿用它的分支）
    $remoteBranches = @()
    $fetch = Invoke-Git @('-C', $ws, 'fetch', 'origin')
    if ($fetch.Code -ne 0) {
        Write-Host '    暂时连不上远程仓库，先按本地设置继续（首次同步时会重试）' -ForegroundColor Yellow
    } else {
        $refs = Invoke-Git @('-C', $ws, 'for-each-ref', '--format=%(refname:short)', 'refs/remotes/origin')
        if ($refs.Code -eq 0 -and $refs.Text) {
            $remoteBranches = @($refs.Text -split "`n" |
                ForEach-Object { $_.Trim() } |
                Where-Object { $_ -match '^origin/[^/]+$' -and $_ -ne 'origin/HEAD' })
        }

        if ($remoteBranches.Count -eq 0) {
            $sym = Invoke-Git @('-C', $ws, 'ls-remote', '--symref', 'origin', 'HEAD')
            if ($sym.Code -eq 0 -and $sym.Text -match 'ref:\s+refs/heads/([^\s]+)\s+HEAD') {
                $remoteDefault = $Matches[1]
                if ($remoteDefault -ne $br) {
                    Write-Host ('    远程仓库的默认分支是 ' + $remoteDefault + '，将以它为准') -ForegroundColor Yellow
                    $br = $remoteDefault
                }
            }
        } elseif (-not ($remoteBranches -contains ('origin/' + $br))) {
            if ($remoteBranches.Count -eq 1) {
                $onlyName = $remoteBranches[0].Substring('origin/'.Length)
                Write-Host ('    远程仓库已有分支 ' + $onlyName + '，将使用它') -ForegroundColor Yellow
                $br = $onlyName
            } else {
                Write-Host ('    注意：远程仓库里没有 ' + $br + ' 分支，将新建一个') -ForegroundColor Yellow
            }
        }
    }

    $headNow = (Invoke-Git @('-C', $ws, 'rev-parse', '--verify', '--quiet', 'HEAD')).Code -eq 0
    if (-not $headNow) {
        Invoke-Git @('-C', $ws, 'symbolic-ref', 'HEAD', ('refs/heads/' + $br)) | Out-Null
        if ($fetch.Code -eq 0 -and ($remoteBranches -contains ('origin/' + $br))) {
            $remoteRef = 'origin/' + $br
            $sep = [System.IO.Path]::DirectorySeparatorChar

            # 先看看本地有没有和仓库同名的文件，有就先备份，绝不直接覆盖
            $tracked = Invoke-Git @('-C', $ws, 'ls-tree', '-r', '--name-only', $remoteRef)
            $collisions = @()
            if ($tracked.Code -eq 0 -and $tracked.Text) {
                foreach ($f in @($tracked.Text -split "`n")) {
                    if (-not $f) { continue }
                    $full = [System.IO.Path]::Combine($ws, $f.Replace('/', $sep))
                    if (Test-Path -LiteralPath $full) { $collisions += $f }
                }
            }

            if ($collisions.Count -gt 0) {
                $stamp  = Get-Date -Format 'yyyyMMdd-HHmmss'
                $backup = Join-Path $ToolDir ('backup-' + $stamp)
                foreach ($f in $collisions) {
                    $src = [System.IO.Path]::Combine($ws, $f.Replace('/', $sep))
                    $dst = [System.IO.Path]::Combine($backup, $f.Replace('/', $sep))
                    $parent = Split-Path -Parent $dst
                    if (-not (Test-Path -LiteralPath $parent)) {
                        New-Item -ItemType Directory -Path $parent -Force | Out-Null
                    }
                    Copy-Item -LiteralPath $src -Destination $dst -Force
                }
                Write-Host ('    本地有 ' + $collisions.Count + ' 个文件和仓库里的同名，已备份到 ' + $backup) -ForegroundColor Yellow
            }

            Invoke-Git @('-C', $ws, 'reset', '--hard', $remoteRef) | Out-Null
            Write-Host '    已把本地目录对齐到远程仓库的最新版本（你自己的文件都还在）' -ForegroundColor Gray
        }
    }

    # 4. 身份与习惯
    Invoke-Git @('-C', $ws, 'config', 'user.name', $V.userName) | Out-Null
    Invoke-Git @('-C', $ws, 'config', 'user.email', $V.userEmail) | Out-Null
    Invoke-Git @('-C', $ws, 'config', 'core.quotepath', 'false') | Out-Null
    Invoke-Git @('-C', $ws, 'config', 'pull.rebase', 'true') | Out-Null
    Invoke-Git @('-C', $ws, 'config', 'push.default', 'simple') | Out-Null

    # 4. .gitignore
    $ignorePath = Join-Path $ws '.gitignore'

    $ignoreSections = @(
        @{
            Title = '编译产物 / 依赖 / 缓存'
            Items = @(
                '__pycache__/', '*.py[cod]', '*.egg-info/', '.venv/', 'venv/',
                'node_modules/', 'build/', 'dist/', 'out/', 'obj/', 'target/',
                '*.o', '*.obj', '*.class', '*.tmp', '*.bak', '*.log', '*.swp'
            )
        },
        @{
            Title = '论文 / 文档 / 演示文稿（默认只同步代码；想把论文也传上去，删掉这一段即可）'
            Items = @(
                '*.doc', '*.docx', '*.docm', '*.pdf', '*.ppt', '*.pptx', '*.pptm',
                '*.wps', '*.dps', '*.key', '*.pages',
                '~$*', '.~lock.*#'
            )
        },
        @{
            Title = '系统文件和编辑器配置'
            Items = @(
                '.env', '.env.*', '*.env', '.DS_Store', 'Thumbs.db', 'desktop.ini', '.vscode/', '.idea/'
            )
        }
    )

    $existingLines = @()
    if (Test-Path -LiteralPath $ignorePath) { $existingLines = [System.IO.File]::ReadAllLines($ignorePath) }

    $set = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($l in $existingLines) { $t = $l.Trim(); if ($t) { [void]$set.Add($t) } }

    $bodyParts = @()
    $addedCount = 0
    foreach ($section in $ignoreSections) {
        $missing = @()
        foreach ($e in $section.Items) { if (-not $set.Contains($e)) { $missing += $e } }
        if ($missing.Count -eq 0) { continue }

        $bodyParts += ('# ---- ' + $section.Title + ' ----')
        foreach ($e in $missing) {
            $bodyParts += $e
            [void]$set.Add($e)
            $addedCount++
        }
        $bodyParts += ''
    }

    if ($addedCount -gt 0) {
        $sb = New-Object System.Text.StringBuilder
        if ($existingLines.Count -gt 0) { [void]$sb.AppendLine('') }
        [void]$sb.AppendLine('# ===== 自动同步工具写入，可按需删改（删掉某行就会开始同步该类文件）=====')
        foreach ($line in $bodyParts) { [void]$sb.AppendLine($line) }
        [System.IO.File]::AppendAllText($ignorePath, $sb.ToString(), $Utf8NoBom)
        Write-Host ('    .gitignore 已补充 ' + $addedCount + ' 条忽略规则') -ForegroundColor Gray
    }

    # 5. 工具目录本身不参与同步
    $wsFull   = [System.IO.Path]::GetFullPath($ws).TrimEnd('\')
    $toolFull = [System.IO.Path]::GetFullPath($ToolDir).TrimEnd('\')
    if ($toolFull.StartsWith($wsFull + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
        $rel = $toolFull.Substring($wsFull.Length + 1).Replace('\', '/')
        $entry = '/' + $rel + '/'
        $lines2 = @()
        if (Test-Path -LiteralPath $ignorePath) { $lines2 = [System.IO.File]::ReadAllLines($ignorePath) }
        $already = @($lines2 | Where-Object { $_.Trim() -eq $entry })
        if ($already.Count -eq 0) {
            [System.IO.File]::AppendAllText($ignorePath, ($entry + "`r`n"), $Utf8NoBom)
            Write-Host ('    已把工具目录 ' + $entry + ' 排除在同步之外') -ForegroundColor Gray
        }
    }

    # 6. 写配置
    $cfg = [pscustomobject][ordered]@{
        workspace         = $ws
        remoteUrl         = $V.remoteUrl
        branch            = $br
        pollSeconds       = 15
        quietSeconds      = 8
        fetchEverySeconds = 45
        maxFileMB         = 90
        userName          = $V.userName
        userEmail         = $V.userEmail
        createdAt         = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    }
    [System.IO.File]::WriteAllText($ConfigPath, ($cfg | ConvertTo-Json -Depth 4), $Utf8NoBom)
    Write-Step '配置已保存'

    # 7. 开机自启
    if ($V.autoStart) {
        if (-not (Test-Path $RunKey)) { New-Item -Path $RunKey -Force | Out-Null }
        Set-ItemProperty -Path $RunKey -Name $RunValue -Value ('wscript.exe "' + $HiddenVbs + '"')

        # 旧版本用的是固定名字，顺手清掉，免得多出一条指向同一个启动器的残留
        $legacyName = 'CompetitionGitAutoSync'
        $legacy = Get-ItemProperty -Path $RunKey -Name $legacyName -ErrorAction SilentlyContinue
        if ($legacy -and $legacy.$legacyName -eq ('wscript.exe "' + $HiddenVbs + '"')) {
            Remove-ItemProperty -Path $RunKey -Name $legacyName -ErrorAction SilentlyContinue
        }

        Write-Step '已设置开机自动启动'
    } else {
        Remove-ItemProperty -Path $RunKey -Name $RunValue -ErrorAction SilentlyContinue
        Write-Step '未设置开机自启（随时再运行本向导可以打开）'
    }

    # 8. 首次同步（可能弹登录）
    Write-Host ''
    Write-Step '第一次同步（如果弹出登录窗口，登录 Git 账号授权即可）'
    Write-Host ''
    $firstOk = $true
    try {
        & $SyncScript -Config $ConfigPath -Once -AllowPrompt
    } catch {
        $firstOk = $false
        Write-Host ('    第一次同步没成功：' + $_.Exception.Message) -ForegroundColor Red
    }

    # 9. 启动后台同步（只停这一个安装的，别误伤另一份）
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object {
            $_.ProcessId -ne $PID -and $_.CommandLine -and
            $_.CommandLine.IndexOf($SyncScript, [System.StringComparison]::OrdinalIgnoreCase) -ge 0
        } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Milliseconds 400
    Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + $HiddenVbs + '"') -WindowStyle Hidden
    Write-Step '后台同步已启动'

    [pscustomobject]@{
        Workspace = $ws
        Branch    = $br
        FirstOk   = $firstOk
        LogDir    = (Join-Path $ToolDir 'logs')
    }
}

try {
    $info = Install-Sync -V $values
} catch {
    Show-Info ("出错了：`n`n" + $_.Exception.Message + "`n`n可以打开『查看状态和日志.bat』看详细原因。") '安装失败' 'Error'
    Write-Host ''
    Write-Host ('安装失败：' + $_.Exception.Message) -ForegroundColor Red
    Write-Host ''
    if (-not $Silent) { Read-Host '按回车关闭' }
    exit 1
}

$msg = "设置完成！`r`n`r`n工作区：$($info.Workspace)`r`n分支：  $($info.Branch)`r`n`r`n之后这里的所有改动都会自动提交并推送到 Git 仓库。`r`n"
if ($info.FirstOk) {
    $msg += "`r`n第一次同步已完成，可以去仓库网页看看代码是不是已经上去了。"
} else {
    $msg += "`r`n第一次同步没成功，多半是网络或账号没登录。双击『立即同步一次.bat』能看到详细提示。"
}
$msg += "`r`n`r`n日志目录：$($info.LogDir)"
$msg += "`r`n`r`n把整个『git-sync』文件夹发给队友，他们各自运行一次就能一起同步。"

Show-Info $msg '完成' 'Information'

if (-not $Silent) { Start-Sleep -Seconds 2 }
