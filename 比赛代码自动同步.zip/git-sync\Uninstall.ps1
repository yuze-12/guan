﻿#Requires -Version 5.1
<#
.SYNOPSIS
    比赛代码自动同步 —— 卸载开机自启 / 停止后台同步

.DESCRIPTION
    停止正在运行的同步进程、删除开机自启项。不会删除你的代码，也不会动 config.json
    以外的任何东西；想彻底清理，直接删掉整个 git-sync 文件夹即可。
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false } catch { }

Add-Type -AssemblyName System.Windows.Forms

$RunKey    = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$RunValue  = 'CompetitionGitAutoSync'
$ToolDir   = $PSScriptRoot

Write-Host ''
Write-Host '===== 停止自动同步 =====' -ForegroundColor Cyan
Write-Host ''

$killed = 0
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -like '*GitSync.ps1*' } |
    ForEach-Object {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
        $killed++
    }
Write-Host ('  已停止 ' + $killed + ' 个后台同步进程') -ForegroundColor Gray

$removed = $false
try {
    $item = Get-ItemProperty -Path $RunKey -Name $RunValue -ErrorAction SilentlyContinue
    if ($item) {
        Remove-ItemProperty -Path $RunKey -Name $RunValue -ErrorAction SilentlyContinue
        $removed = $true
    }
} catch { }

if ($removed) {
    Write-Host '  已取消开机自启' -ForegroundColor Gray
} else {
    Write-Host '  本来就没有设置开机自启' -ForegroundColor Gray
}

$msg = "已停止自动同步，并取消开机自启。`n`n代码文件、Git 仓库、日志都还在，什么都没删。`n`n想继续用：双击『安装并开始同步.bat』即可。"
if ($killed -eq 0 -and -not $removed) {
    $msg = "没有找到正在运行的同步进程，也没有开机自启项。`n`n可能已经停过了。"
}

[System.Windows.Forms.MessageBox]::Show($msg, '已停止', 'OK', 'Information') | Out-Null
