﻿#Requires -Version 5.1
<#
.SYNOPSIS
    比赛代码自动同步 —— 后台守护进程

.DESCRIPTION
    监视 config.json 指定的工作区（即一个 Git 仓库），一旦发现文件变化就自动 commit，
    然后 fetch / rebase / push 到远程仓库。断网时只把改动提交到本地，网络恢复后自动补推，
    不会丢代码。冲突时不做任何破坏性操作，只记录日志并保留本地文件。

.PARAMETER Config
    配置文件路径，默认是本脚本同目录下的 config.json

.PARAMETER Once
    只同步一轮就退出，并把过程输出到控制台（适合手动点一下 / 排查问题）

.PARAMETER AllowPrompt
    允许 git 弹出账号密码或浏览器登录框（首次推送必须开，后台常驻时不要开）

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File GitSync.ps1 -Once -AllowPrompt
#>
[CmdletBinding()]
param(
    [string]$Config = '',
    [switch]$Once,
    [switch]$AllowPrompt
)

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false } catch { }

$Script:ToolDir    = $PSScriptRoot
$Script:ConsoleOut = [bool]$Once
$Script:LastCommit = $null
$Script:LastPull   = $null
$Script:LastPush   = $null
$Script:LastFetch  = [datetime]::MinValue
$Script:ConflictUntil = $null
$Script:Cfg        = $null
$Script:Repo       = ''
$Script:Branch     = 'main'

if ([string]::IsNullOrWhiteSpace($Config)) { $Config = Join-Path $Script:ToolDir 'config.json' }
$Script:ConfigPath = $Config
$Script:LogDir     = Join-Path $Script:ToolDir 'logs'
$Script:StatusJson = Join-Path $Script:ToolDir 'status.json'
$Script:StatusTxt  = Join-Path $Script:ToolDir 'status.txt'

$Script:Utf8NoBom = New-Object System.Text.UTF8Encoding $false

# ============================================================ 日志 / 状态

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO', 'OK', 'WARN', 'ERROR')][string]$Level = 'INFO'
    )
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    try {
        if (-not (Test-Path -LiteralPath $Script:LogDir)) {
            New-Item -ItemType Directory -Path $Script:LogDir -Force | Out-Null
        }
        $path = Join-Path $Script:LogDir ('sync-{0}.log' -f (Get-Date -Format 'yyyyMMdd'))
        Add-Content -LiteralPath $path -Value $line -Encoding UTF8
    } catch { }

    if ($Script:ConsoleOut) {
        switch ($Level) {
            'OK'    { Write-Host $line -ForegroundColor Green }
            'WARN'  { Write-Host $line -ForegroundColor Yellow }
            'ERROR' { Write-Host $line -ForegroundColor Red }
            default { Write-Host $line -ForegroundColor Gray }
        }
    }
}

function Update-Status {
    param([string]$State, [string]$ErrorText = '')

    $now = Get-Date
    $lastCommit = ''
    $lastPull   = ''
    $lastPush   = ''
    if ($Script:LastCommit) { $lastCommit = $Script:LastCommit.ToString('yyyy-MM-dd HH:mm:ss') }
    if ($Script:LastPull)   { $lastPull   = $Script:LastPull.ToString('yyyy-MM-dd HH:mm:ss') }
    if ($Script:LastPush)   { $lastPush   = $Script:LastPush.ToString('yyyy-MM-dd HH:mm:ss') }

    $label = switch ($State) {
        'ok'          { '正常' }
        'offline'     { '离线，等待网络（本地改动已安全提交）' }
        'conflict'    { '有冲突，需要人工处理一次' }
        'push-failed' { '推送失败，稍后自动重试' }
        default       { '出错' }
    }

    $obj = [pscustomobject][ordered]@{
        state      = $State
        stateLabel = $label
        updatedAt  = $now.ToString('yyyy-MM-dd HH:mm:ss')
        workspace  = $Script:Repo
        branch     = $Script:Branch
        host       = $env:COMPUTERNAME
        lastCommit = $lastCommit
        lastPull   = $lastPull
        lastPush   = $lastPush
        lastError  = $ErrorText
    }

    try {
        $json = $obj | ConvertTo-Json -Depth 4
        [System.IO.File]::WriteAllText($Script:StatusJson, $json, $Script:Utf8NoBom)
    } catch { }

    $txt = @()
    $txt += '比赛代码自动同步 · 当前状态'
    $txt += '--------------------------------'
    $txt += ('状态      ：' + $label)
    $txt += ('工作区    ：' + $Script:Repo)
    $txt += ('分支      ：' + $Script:Branch)
    $txt += ('最近提交  ：' + $(if ($lastCommit) { $lastCommit } else { '暂无' }))
    $txt += ('最近接收  ：' + $(if ($lastPull)   { $lastPull }   else { '暂无' }))
    $txt += ('最近推送  ：' + $(if ($lastPush)   { $lastPush }   else { '暂无' }))
    $txt += ('检查时间  ：' + $now.ToString('yyyy-MM-dd HH:mm:ss'))
    if ($ErrorText) { $txt += ('提示      ：' + $ErrorText) }

    try { [System.IO.File]::WriteAllText($Script:StatusTxt, ($txt -join "`r`n"), $Script:Utf8NoBom) } catch { }
}

# ============================================================ 配置

function Get-Cfg {
    if (-not (Test-Path -LiteralPath $Script:ConfigPath)) {
        throw "找不到配置文件 $($Script:ConfigPath)，请先双击『安装并开始同步.bat』"
    }

    $raw = [System.IO.File]::ReadAllText($Script:ConfigPath, [System.Text.Encoding]::UTF8)
    $o = $raw | ConvertFrom-Json

    $ws = [string]$o.workspace
    if ([string]::IsNullOrWhiteSpace($ws)) { throw '配置文件里没有工作区目录（workspace）' }
    if (-not (Test-Path -LiteralPath $ws)) { throw "工作区目录不存在：$ws" }

    $branch = [string]$o.branch
    if ([string]::IsNullOrWhiteSpace($branch)) { $branch = 'main' }

    $remote = [string]$o.remoteUrl
    if ([string]::IsNullOrWhiteSpace($remote)) { throw '配置文件里没有远程仓库地址（remoteUrl）' }

    $poll = 15
    if ($o.pollSeconds) { $poll = [int]$o.pollSeconds }
    if ($poll -lt 5) { $poll = 5 }

    $quiet = 8
    if ($o.quietSeconds) { $quiet = [int]$o.quietSeconds }
    if ($quiet -lt 0) { $quiet = 0 }

    $fetchEvery = 45
    if ($o.fetchEverySeconds) { $fetchEvery = [int]$o.fetchEverySeconds }
    if ($fetchEvery -lt 10) { $fetchEvery = 10 }

    $maxMB = 90
    if ($o.maxFileMB) { $maxMB = [int]$o.maxFileMB }

    [pscustomobject]@{
        workspace        = $ws
        remoteUrl        = $remote
        branch           = $branch
        pollSeconds      = $poll
        quietSeconds     = $quiet
        fetchEverySeconds = $fetchEvery
        maxFileMB        = $maxMB
        userName         = [string]$o.userName
        userEmail        = [string]$o.userEmail
    }
}

# ============================================================ git 调用

function Invoke-Git {
    param([Parameter(Mandatory)][string[]]$Arguments)

    $previous = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $lines = & git @Arguments 2>&1
        $code  = $LASTEXITCODE
        if ($null -eq $lines) {
            $text = ''
        } else {
            $text = (($lines | ForEach-Object { "$_" }) -join "`n")
        }
    } finally {
        $ErrorActionPreference = $previous
    }

    [pscustomobject]@{ Code = $code; Text = $text.Trim() }
}

function Invoke-RepoGit {
    param([Parameter(Mandatory)][string[]]$Arguments)
    Invoke-Git (@('-C', $Script:Repo) + $Arguments)
}

function Get-RepoState {
    $r = Invoke-RepoGit @('status', '--porcelain', '-uall')
    if ($r.Code -ne 0) {
        return [pscustomobject]@{ Ok = $false; Text = $r.Text; Count = -1 }
    }
    $count = 0
    if ($r.Text) { $count = ($r.Text -split "`n").Count }
    [pscustomobject]@{ Ok = $true; Text = $r.Text; Count = $count }
}

# ============================================================ 超大文件保护

function ConvertTo-IgnorePattern {
    param([string]$Path)
    $p = $Path.Replace('\', '/')
    $sb = New-Object System.Text.StringBuilder
    foreach ($ch in $p.ToCharArray()) {
        if ('\*?[]#!'.IndexOf($ch) -ge 0) { [void]$sb.Append('\') }
        [void]$sb.Append($ch)
    }
    '/' + $sb.ToString()
}

function Protect-OversizeFiles {
    $maxMB = [int]$Script:Cfg.maxFileMB
    if ($maxMB -le 0) { return @() }
    $limit = [int64]$maxMB * 1MB

    $r = Invoke-RepoGit @('ls-files', '-z', '--others', '--exclude-standard')
    if ($r.Code -ne 0 -or [string]::IsNullOrEmpty($r.Text)) { return @() }

    $paths = $r.Text -split "`0" | Where-Object { $_ }
    $tooBig = New-Object System.Collections.Generic.List[string]

    foreach ($p in $paths) {
        $full = [System.IO.Path]::Combine($Script:Repo, $p.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        try {
            $info = New-Object System.IO.FileInfo($full)
            if ($info.Exists -and $info.Length -gt $limit) { $tooBig.Add($p) }
        } catch { }
    }

    if ($tooBig.Count -eq 0) { return @() }

    $excludePath = Join-Path $Script:Repo '.git\info\exclude'
    $excludeDir = Split-Path -Parent $excludePath
    if (-not (Test-Path -LiteralPath $excludeDir)) {
        New-Item -ItemType Directory -Path $excludeDir -Force | Out-Null
    }

    $existing = ''
    if (Test-Path -LiteralPath $excludePath) {
        $existing = [System.IO.File]::ReadAllText($excludePath)
    }

    $added = @()
    foreach ($p in $tooBig) {
        $pattern = ConvertTo-IgnorePattern $p
        if ($existing.IndexOf($pattern, [System.StringComparison]::Ordinal) -lt 0) {
            $existing = $existing.TrimEnd() + "`r`n# auto-sync: 超过大小限制，自动跳过`r`n" + $pattern + "`r`n"
            $added += $p
        }
    }

    if ($added.Count -gt 0) {
        [System.IO.File]::WriteAllText($excludePath, $existing, $Script:Utf8NoBom)
    }

    return $added
}

# ============================================================ 提交

function Save-Changes {
    $state = Get-RepoState
    if (-not $state.Ok) {
        Write-Log "git status 执行失败：$($state.Text)" 'ERROR'
        return $false
    }
    if ($state.Count -le 0) { return $false }

    # 等文件写入稳定（避免把一个写到一半的文件提交上去）
    $quiet = [int]$Script:Cfg.quietSeconds
    $lastSig = ''
    $stable = $false
    $deadline = (Get-Date).AddSeconds([Math]::Max(60, ($quiet + 2) * 6))

    while ((Get-Date) -lt $deadline) {
        $sig = (Get-RepoState).Text
        if ($sig -eq $lastSig) { $stable = $true; break }
        $lastSig = $sig
        Start-Sleep -Seconds ([Math]::Max(2, $quiet))
    }
    if (-not $stable) { Write-Log '工作区文件一直在变，先提交当前这一版' 'WARN' }

    $big = Protect-OversizeFiles
    if ($big -and $big.Count -gt 0) {
        Write-Log ('以下文件超过 {0} MB，已自动加入 .git/info/exclude 并跳过：{1}' -f $Script:Cfg.maxFileMB, ($big -join ' ; ')) 'WARN'
    }

    $add = Invoke-RepoGit @('add', '-A')
    if ($add.Code -ne 0) {
        Write-Log "git add 失败：$($add.Text)" 'ERROR'
        return $false
    }

    $staged = Invoke-RepoGit @('diff', '--cached', '--name-status')
    if (-not $staged.Text) { return $false }

    $lines = @($staged.Text -split "`n" | Where-Object { $_ })
    $bodyLines = @($lines | Select-Object -First 20)
    if ($lines.Count -gt 20) { $bodyLines += ('... 共 ' + $lines.Count + ' 个文件') }
    $body = $bodyLines -join "`n"

    $title = 'auto-sync: {0} {1}' -f $env:COMPUTERNAME, (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    $commit = Invoke-RepoGit @('commit', '--no-verify', '-m', $title, '-m', $body)
    if ($commit.Code -ne 0) {
        if ($commit.Text -match 'nothing to commit') { return $false }
        Write-Log "git commit 失败：$($commit.Text)" 'ERROR'
        return $false
    }

    Write-Log ('已提交 {0} 个文件（{1}）' -f $lines.Count, $title) 'OK'
    $Script:LastCommit = Get-Date
    return $true
}

# ============================================================ 一轮同步

function Invoke-SyncCycle {
    $repo = $Script:Repo

    if (-not (Test-Path -LiteralPath (Join-Path $repo '.git'))) {
        Write-Log "工作区不是 Git 仓库：$repo" 'ERROR'
        Update-Status 'error' '工作区不是 git 仓库'
        return
    }

    $lockPath = Join-Path $repo '.git\index.lock'
    if (Test-Path -LiteralPath $lockPath) {
        $ageMin = ((Get-Date) - (Get-Item -LiteralPath $lockPath).LastWriteTime).TotalMinutes
        if ($ageMin -lt 20) {
            Write-Log 'git 索引被其它程序占用中，本轮跳过' 'WARN'
            return
        }
        Remove-Item -LiteralPath $lockPath -Force -ErrorAction SilentlyContinue
        Write-Log '清理了残留的 .git/index.lock' 'WARN'
    }

    $committed = Save-Changes

    # ---- 抓取远程
    $fetch = Invoke-RepoGit @('fetch', '--prune', 'origin')
    if ($fetch.Code -ne 0) {
        Write-Log "暂时连不上远程仓库，稍后自动重试：$($fetch.Text)" 'WARN'
        Update-Status 'offline' $fetch.Text
        return
    }
    $Script:LastFetch = Get-Date

    # 冲突后静默一分钟再重试，避免每 15 秒刷一次同样的错误
    if ($Script:ConflictUntil -and (Get-Date) -lt $Script:ConflictUntil) {
        if ($committed) { Write-Log '上次的冲突还没解决，这次只提交到本地，稍后自动重试合并' 'WARN' }
        Update-Status 'conflict' '等待冲突解决后自动重试'
        return
    }

    $remoteRef = 'origin/' + $Script:Branch
    $hasRemote = (Invoke-RepoGit @('rev-parse', '--verify', '--quiet', $remoteRef)).Code -eq 0
    $hasHead = (Invoke-RepoGit @('rev-parse', '--verify', '--quiet', 'HEAD')).Code -eq 0

    if (-not $hasHead) {
        # 工作区还是空的，没有任何提交，不需要推送
        Update-Status 'ok'
        return
    }

    # ---- 先接收别人的改动
    if ($hasRemote) {
        $counts = Invoke-RepoGit @('rev-list', '--count', '--left-right', ($remoteRef + '...HEAD'))
        $behind = 0
        if ($counts.Code -eq 0 -and $counts.Text -match '^(\d+)\s+(\d+)$') {
            $behind = [int]$Matches[1]
        }

        if ($behind -gt 0) {
            $rebase = Invoke-RepoGit @('rebase', '--autostash', $remoteRef)
            if ($rebase.Code -ne 0) {
                $conflicts = ''
                try {
                    $conflicts = (Invoke-RepoGit @('diff', '--name-only', '--diff-filter=U')).Text
                } catch { }

                $inRebase = (Test-Path -LiteralPath (Join-Path $repo '.git\rebase-merge')) -or
                            (Test-Path -LiteralPath (Join-Path $repo '.git\rebase-apply'))
                if ($inRebase) { Invoke-RepoGit @('rebase', '--abort') | Out-Null }

                $Script:ConflictUntil = (Get-Date).AddSeconds(60)
                Write-Log ('和队友的改动冲突了，已撤销合并、你的文件原样保留。冲突文件：' + $conflicts) 'ERROR'
                Update-Status 'conflict' ('冲突文件：' + $conflicts)
                return
            }

            Write-Log ('已接收远程仓库的 ' + $behind + ' 个新提交') 'OK'
            $Script:LastPull = Get-Date
        }
    }

    # ---- 再推送自己的提交
    $ahead = 0
    if ($hasRemote) {
        $counts = Invoke-RepoGit @('rev-list', '--count', ($remoteRef + '..HEAD'))
        if ($counts.Code -eq 0) {
            $digits = $counts.Text -replace '\D', ''
            if ($digits) { $ahead = [int]$digits }
        }
    } else {
        $ahead = 1
    }

    if ($ahead -gt 0) {
        $push = Invoke-RepoGit @('push', 'origin', ('HEAD:refs/heads/' + $Script:Branch))
        if ($push.Code -ne 0) {
            Write-Log "推送失败，下一轮自动重试：$($push.Text)" 'ERROR'
            Update-Status 'push-failed' $push.Text
            return
        }
        Write-Log '已推送到远程仓库' 'OK'
        $Script:LastPush = Get-Date
    }

    if (-not $committed -and $ahead -le 0) {
        Write-Log '没有变化，本轮空跑' 'INFO'
    }

    $Script:ConflictUntil = $null
    Update-Status 'ok'
}

# ============================================================ 启动

function Initialize-GitEnv {
    param($Cfg)

    $env:GIT_TERMINAL_PROMPT = '0'
    if ($AllowPrompt) { $env:GIT_TERMINAL_PROMPT = '1' }
    $env:GIT_PAGER = 'cat'
    $env:GIT_HTTP_LOW_SPEED_LIMIT = '1000'
    $env:GIT_HTTP_LOW_SPEED_TIME = '30'

    $url = [string]$Cfg.remoteUrl
    if ($url.StartsWith('git@') -or $url.ToLower().StartsWith('ssh://')) {
        if ($AllowPrompt) {
            $env:GIT_SSH_COMMAND = 'ssh -o ConnectTimeout=15'
        } else {
            $env:GIT_SSH_COMMAND = 'ssh -o ConnectTimeout=15 -o BatchMode=yes'
        }
    }
}

function Ensure-Identity {
    # 克隆来的仓库可能没有提交身份，用配置里的补上（缺什么补什么，不动已有的）
    if (-not [string]::IsNullOrWhiteSpace($Script:Cfg.userName)) {
        $cur = Invoke-RepoGit @('config', 'user.name')
        if ($cur.Code -ne 0 -or [string]::IsNullOrWhiteSpace($cur.Text)) {
            Invoke-RepoGit @('config', 'user.name', $Script:Cfg.userName) | Out-Null
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($Script:Cfg.userEmail)) {
        $cur = Invoke-RepoGit @('config', 'user.email')
        if ($cur.Code -ne 0 -or [string]::IsNullOrWhiteSpace($cur.Text)) {
            Invoke-RepoGit @('config', 'user.email', $Script:Cfg.userEmail) | Out-Null
        }
    }
}

function Clear-OldLogs {
    try {
        if (-not (Test-Path -LiteralPath $Script:LogDir)) { return }
        Get-ChildItem -LiteralPath $Script:LogDir -Filter 'sync-*.log' -ErrorAction SilentlyContinue |
            Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-14) } |
            Remove-Item -Force -ErrorAction SilentlyContinue
    } catch { }
}

try {
    $Script:Cfg = Get-Cfg
} catch {
    Write-Log $_.Exception.Message 'ERROR'
    exit 1
}

$Script:Repo   = (Resolve-Path -LiteralPath $Script:Cfg.workspace).Path
$Script:Branch = $Script:Cfg.branch

Initialize-GitEnv $Script:Cfg
Clear-OldLogs
Ensure-Identity

if ($Once) {
    Write-Log ('手动同步一次：' + $Script:Repo + '（分支 ' + $Script:Branch + '）')
    Invoke-SyncCycle
    return
}

# 同一时间只允许一个同步进程
$mutex = New-Object System.Threading.Mutex($false, 'Local\CompetitionGitAutoSync')
$held = $false
try { $held = $mutex.WaitOne(0) } catch { $held = $true }
if (-not $held) {
    Write-Log '已经有一个同步进程在运行，本次启动退出'
    return
}

Write-Log '===== 自动同步已启动 ====='
Write-Log ('工作区：' + $Script:Repo)
Write-Log ('远程：  ' + $Script:Cfg.remoteUrl + '  分支：' + $Script:Branch)
Write-Log ('轮询：  每 ' + $Script:Cfg.pollSeconds + ' 秒检查一次')

$configStamp = (Get-Item -LiteralPath $Script:ConfigPath).LastWriteTimeUtc

while ($true) {
    try {
        $stamp = (Get-Item -LiteralPath $Script:ConfigPath).LastWriteTimeUtc
        if ($stamp -ne $configStamp) {
            $newCfg = Get-Cfg
            $Script:Cfg = $newCfg
            $Script:Repo = (Resolve-Path -LiteralPath $newCfg.workspace).Path
            $Script:Branch = $newCfg.branch
            Initialize-GitEnv $newCfg
            Ensure-Identity
            $configStamp = $stamp
            Write-Log '配置已更新，重新加载'
        }

        Invoke-SyncCycle
    } catch {
        Write-Log ('本轮同步出错：' + $_.Exception.Message) 'ERROR'
        Update-Status 'error' $_.Exception.Message
    }

    Start-Sleep -Seconds ([int]$Script:Cfg.pollSeconds)
}
