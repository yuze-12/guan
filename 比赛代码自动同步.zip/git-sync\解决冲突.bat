@echo off
chcp 65001 >nul
title Git Auto Sync - Resolve Conflict
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ResolveConflict.ps1"

echo.
pause
