﻿#Requires -Version 5.1
<#
.SYNOPSIS
    比赛代码自动同步 —— 查看当前状态和最近的同步日志
#>
[CmdletBinding()]
param([int]$Tail = 30)

$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false } catch { }

$ToolDir   = $PSScriptRoot
$StatusTxt = Join-Path $ToolDir 'status.txt'
$LogDir    = Join-Path $ToolDir 'logs'

Write-Host ''

if (Test-Path -LiteralPath $StatusTxt) {
    Get-Content -LiteralPath $StatusTxt -Encoding UTF8 | ForEach-Object { Write-Host $_ }
} else {
    Write-Host '还没有同步过（找不到 status.txt）。' -ForegroundColor Yellow
    Write-Host '双击『安装并开始同步.bat』完成设置，或者双击『立即同步一次.bat』手动跑一次。'
}

Write-Host ''
Write-Host '--------------------------------' -ForegroundColor DarkGray

function Get-PathId {
    param([string]$Path)
    $sha = [System.Security.Cryptography.SHA1]::Create()
    try { $hash = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Path.ToLowerInvariant())) }
    finally { $sha.Dispose() }
    return (($hash | ForEach-Object { $_.ToString('x2') }) -join '').Substring(0, 8)
}

$SyncScript = Join-Path $ToolDir 'GitSync.ps1'
$RunValue   = 'CompetitionGitAutoSync_' + (Get-PathId $ToolDir)

$running = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object {
        $_.ProcessId -ne $PID -and $_.CommandLine -and
        $_.CommandLine.IndexOf($SyncScript, [System.StringComparison]::OrdinalIgnoreCase) -ge 0
    })

if ($running.Count -gt 0) {
    Write-Host ('后台同步：正在运行（进程 ' + ($running.ProcessId -join ', ') + '）') -ForegroundColor Green
} else {
    Write-Host '后台同步：没有在运行' -ForegroundColor Yellow
    Write-Host '  → 双击『安装并开始同步.bat』可以重新启动并设置开机自启。'
}

$startup = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name $RunValue -ErrorAction SilentlyContinue
if ($startup) {
    Write-Host '开机自启：已开启' -ForegroundColor Green
} else {
    Write-Host '开机自启：未开启' -ForegroundColor Yellow
}

Write-Host ''
Write-Host ('最近 ' + $Tail + ' 条日志：') -ForegroundColor DarkGray
Write-Host ''

if (Test-Path -LiteralPath $LogDir) {
    $latest = Get-ChildItem -LiteralPath $LogDir -Filter 'sync-*.log' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latest) {
        Get-Content -LiteralPath $latest.FullName -Encoding UTF8 -Tail $Tail | ForEach-Object { Write-Host $_ }
        Write-Host ''
        Write-Host ('日志文件：' + $latest.FullName) -ForegroundColor DarkGray
    } else {
        Write-Host '（没有日志文件）'
    }
} else {
    Write-Host '（没有日志目录，说明还没同步过）'
}

Write-Host ''
