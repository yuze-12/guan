' ------------------------------------------------------------
'  Git auto-sync - silent launcher
'  Starts GitSync.ps1 without opening a console window.
'  This file must stay ASCII-only.
' ------------------------------------------------------------
Option Explicit

Dim fso, sh, baseDir, ps1, cfg, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")

baseDir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = baseDir & "\GitSync.ps1"
cfg = baseDir & "\config.json"

If Not fso.FileExists(ps1) Then
    WScript.Echo "GitSync.ps1 not found next to this launcher: " & ps1
    WScript.Quit 1
End If

cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1 & """ -Config """ & cfg & """"
sh.Run cmd, 0, False
