@echo off
chcp 65001 >nul
title Git Auto Sync - Status
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ShowStatus.ps1"

echo.
pause
