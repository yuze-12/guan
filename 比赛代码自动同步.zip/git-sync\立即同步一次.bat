@echo off
chcp 65001 >nul
title Git Auto Sync - Sync Now
cd /d "%~dp0"

if not exist "%~dp0config.json" (
    echo.
    echo   Not configured yet. Please run "install and start" first.
    echo.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0GitSync.ps1" -Config "%~dp0config.json" -Once -AllowPrompt

echo.
pause
