@echo off
chcp 65001 >nul
title Git Auto Sync - Setup
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup.ps1"

echo.
pause
