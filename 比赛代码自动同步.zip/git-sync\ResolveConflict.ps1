﻿#Requires -Version 5.1
<#
.SYNOPSIS
    比赛代码自动同步 —— 冲突处理助手

.DESCRIPTION
    和队友同时改了同一个文件的同一段时，工具会停下来保护你的文件。这个脚本帮你把
    卡住的状态理顺：
      1. 先重新尝试合并，如果其实已经不冲突了就直接结束；
      2. 否则把还没推出去的提交拆回工作区（你的文件内容一个字都不会动）；
      3. 逐个冲突文件问你要保留自己的还是用队友（远程）的版本。

    处理完之后后台同步会在 1 分钟内自动继续。
#>
[CmdletBinding()]
param([string]$Config = '')

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false } catch { }

$ToolDir = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($Config)) { $Config = Join-Path $ToolDir 'config.json' }

function Invoke-Git {
    param([Parameter(Mandatory)][string[]]$Arguments)
    $previous = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $lines = & git @Arguments 2>&1
        $code  = $LASTEXITCODE
        if ($null -eq $lines) { $text = '' } else { $text = (($lines | ForEach-Object { "$_" }) -join "`n") }
    } finally {
        $ErrorActionPreference = $previous
    }
    [pscustomobject]@{ Code = $code; Text = $text.Trim() }
}

if (-not (Test-Path -LiteralPath $Config)) {
    Write-Host ''
    Write-Host '还没配置过，先双击『安装并开始同步.bat』。' -ForegroundColor Yellow
    Write-Host ''
    Read-Host '按回车关闭'
    exit 1
}

$raw = [System.IO.File]::ReadAllText($Config, [System.Text.Encoding]::UTF8)
$cfg = $raw | ConvertFrom-Json

$repo   = (Resolve-Path -LiteralPath ([string]$cfg.workspace)).Path
$branch = [string]$cfg.branch
if ([string]::IsNullOrWhiteSpace($branch)) { $branch = 'main' }
$remoteRef = 'origin/' + $branch

$env:GIT_TERMINAL_PROMPT = '1'
$env:GIT_PAGER = 'cat'

Write-Host ''
Write-Host '===== 冲突处理助手 =====' -ForegroundColor Cyan
Write-Host ('工作区：' + $repo)
Write-Host ('分支：  ' + $branch)
Write-Host ''

Write-Host '正在从远程取最新版本…'
$fetch = Invoke-Git @('-C', $repo, 'fetch', 'origin')
if ($fetch.Code -ne 0) {
    Write-Host ''
    Write-Host ('连不上远程仓库，先把网络弄好再来：' + $fetch.Text) -ForegroundColor Red
    Write-Host ''
    Read-Host '按回车关闭'
    exit 1
}

# 万一还停在某个中间状态，先恢复干净
foreach ($state in @('rebase-merge', 'rebase-apply', 'MERGE_HEAD')) {
    $p = Join-Path $repo ('.git\' + $state)
    if (Test-Path -LiteralPath $p) {
        Invoke-Git @('-C', $repo, 'rebase', '--abort') | Out-Null
        Invoke-Git @('-C', $repo, 'merge', '--abort') | Out-Null
    }
}

$hasRemote = (Invoke-Git @('-C', $repo, 'rev-parse', '--verify', '--quiet', $remoteRef)).Code -eq 0
if (-not $hasRemote) {
    Write-Host '远程仓库上还没有这个分支，没有冲突可处理。' -ForegroundColor Green
    Write-Host ''
    Read-Host '按回车关闭'
    exit 0
}

# 先试一次合并，看看还冲不冲突
$try = Invoke-Git @('-C', $repo, 'rebase', '--autostash', $remoteRef)
if ($try.Code -eq 0) {
    Write-Host ''
    Write-Host '已经没有冲突了，合并成功。' -ForegroundColor Green
    Write-Host '后台同步会在下一轮把改动推上去。'
    Write-Host ''
    Read-Host '按回车关闭'
    exit 0
}

$conflicts = @()
$unmerged = Invoke-Git @('-C', $repo, 'diff', '--name-only', '--diff-filter=U')
if ($unmerged.Code -eq 0 -and $unmerged.Text) {
    $conflicts = @($unmerged.Text -split "`n" | Where-Object { $_ })
}
Invoke-Git @('-C', $repo, 'rebase', '--abort') | Out-Null

# 把你的提交拆回工作区，文件内容和原来一模一样
$reset = Invoke-Git @('-C', $repo, 'reset', '--soft', $remoteRef)
if ($reset.Code -ne 0) {
    Write-Host ''
    Write-Host ('重置本地提交失败：' + $reset.Text) -ForegroundColor Red
    Write-Host ''
    Read-Host '按回车关闭'
    exit 1
}

Write-Host ''
if ($conflicts.Count -eq 0) {
    Write-Host '没找到具体的冲突文件，可能是历史对不上。' -ForegroundColor Yellow
    Write-Host '你的文件内容都还在，后台同步会重新提交它们。'
    Write-Host ''
    Read-Host '按回车关闭'
    exit 0
}

Write-Host ('有 ' + $conflicts.Count + ' 个文件两边都改过：') -ForegroundColor Yellow
Write-Host ''

$kept = 0
$taken = 0
$skipped = 0

foreach ($f in $conflicts) {
    Write-Host ('  ' + $f) -ForegroundColor White
    Write-Host '     [1] 保留我的版本（如果和队友的内容不一样，之后还会提示冲突）'
    Write-Host '     [2] 用队友（远程）的版本'
    Write-Host '     [3] 先跳过，我自己开编辑器改'
    $answer = Read-Host '     选哪个 (默认 3)'
    Write-Host ''

    switch ($answer.Trim()) {
        '1' { $kept++ }
        '2' {
            $co = Invoke-Git @('-C', $repo, 'checkout', $remoteRef, '--', $f)
            if ($co.Code -eq 0) {
                Write-Host ('     已用远程版本覆盖 ' + $f) -ForegroundColor Green
                $taken++
            } else {
                Write-Host ('     覆盖失败：' + $co.Text) -ForegroundColor Red
            }
        }
        default { $skipped++ }
    }
}

Write-Host ''
Write-Host '--------------------------------' -ForegroundColor DarkGray
Write-Host ('保留我的：' + $kept + '    用远程的：' + $taken + '    待自己改：' + $skipped)
Write-Host ''
if ($skipped -gt 0 -or $kept -gt 0) {
    Write-Host '接下来：打开上面这些文件，把内容改成你和队友商量好的样子，保存即可。' -ForegroundColor Yellow
    Write-Host '后台同步会在 1 分钟内自动提交并推送。'
} else {
    Write-Host '处理完了，后台同步会在 1 分钟内自动提交并推送。' -ForegroundColor Green
}
Write-Host ''
Read-Host '按回车关闭'
